<img src="docs/_images/FS_PlantPredict_Logo_Horz_RGB-01.png" width="50%" height="50%">

# plantpredict-python

Install **latest stable version** (1.0.15) via: `pip install plantpredict`.

Install **development version** via GitHub master branch.

---

Documentation can be found at https://plantpredict-python.readthedocs.io

Email **support@plantpredict.com** to sign-up for important email updates.
