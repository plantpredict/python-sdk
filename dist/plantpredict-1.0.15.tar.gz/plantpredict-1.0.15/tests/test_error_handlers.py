import unittest
import mock
import requests

from plantpredict.error_handlers import handle_refused_connection


class TestErrorHandlers(unittest.TestCase):
    pass
    # TODO
