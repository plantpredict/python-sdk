from plantpredict.api import Api
from plantpredict.error_handlers import APIError
from setup import version

__version__ = version
